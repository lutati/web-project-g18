let z = document.getElementById("editD");
z.style.display = "none";
function editing() {
    z.style.display = "block";
}

let x = document.getElementById("deleteD");
x.style.display = "none";
function deleting() {
    x.style.display = "block";
}
