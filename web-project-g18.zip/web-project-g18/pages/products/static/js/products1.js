function malabi_options() {
          var x = document.getElementById("malabi_options");
          if (x.style.display == "none" || x.style.display == "") {
              x.style.display = "block";
          } else {
              x.style.display = "none";
          }
      }

          function rose_options() {
              var y = document.getElementById("rose_options");
              if (y.style.display == "none" || y.style.display == "") {
                  y.style.display = "block";
              } else {
                  y.style.display = "none";
              }
          }

          function sahlav_options() {
              var x = document.getElementById("sahlav_options");
              if (x.style.display == "none" || x.style.display == "") {
                  x.style.display = "block";
              } else {
                  x.style.display = "none";
              }

      }



